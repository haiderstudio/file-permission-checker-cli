#!/bin/sh
echo "all good"
